package Bar;

sub new { bless {} => shift }
sub bar { 1 }

1;
