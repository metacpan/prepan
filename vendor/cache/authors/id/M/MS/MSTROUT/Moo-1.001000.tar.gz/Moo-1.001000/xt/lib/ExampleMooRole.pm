package ExampleMooRole;
use Moo::Role;

$::ExampleMooRole_LOADED++;

no Moo::Role;

1;
