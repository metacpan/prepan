package Qudo::Driver::Skinny::Row::Func;
use strict;
use warnings;
use base 'DBIx::Skinny::Row';

1;
