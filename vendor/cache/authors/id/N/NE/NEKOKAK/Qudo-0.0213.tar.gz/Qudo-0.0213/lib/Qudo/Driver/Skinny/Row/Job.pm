package Qudo::Driver::Skinny::Row::Job;
use strict;
use warnings;
use base 'DBIx::Skinny::Row';

1;
