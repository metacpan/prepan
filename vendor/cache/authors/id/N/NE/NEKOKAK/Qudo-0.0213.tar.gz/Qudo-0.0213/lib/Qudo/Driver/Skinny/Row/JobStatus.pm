package Qudo::Driver::Skinny::Row::JobStatus;
use strict;
use warnings;
use base 'DBIx::Skinny::Row';

1;
