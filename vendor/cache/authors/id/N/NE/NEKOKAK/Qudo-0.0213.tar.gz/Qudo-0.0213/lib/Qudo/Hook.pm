package Qudo::Hook;
use strict;
use warnings;

sub load {
    warn 'this method is abstract';
}

sub unload {
    warn 'this method is abstract';
}

1;

