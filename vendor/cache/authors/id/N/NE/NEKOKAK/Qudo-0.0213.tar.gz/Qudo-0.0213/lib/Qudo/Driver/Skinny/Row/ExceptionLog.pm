package Qudo::Driver::Skinny::Row::ExceptionLog;
use strict;
use warnings;
use base 'DBIx::Skinny::Row';

1;
