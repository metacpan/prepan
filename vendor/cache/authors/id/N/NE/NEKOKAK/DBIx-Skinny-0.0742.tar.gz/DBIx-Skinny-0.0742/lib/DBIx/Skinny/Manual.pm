=head1 NAME

DBIx::Skinny::Manual - DBIx::Skinny Manual

=head1 DESCRIPTION

This document is the entry point for the L<DBIx::Skinny> manuals:

=head2 English

Visit <DBIx:: Skinny:: Manual::EN> for the English manual.

=head2 Japanese

Visit <DBIx:: Skinny:: Manual::JA> for the Japanese manual.


=cut

