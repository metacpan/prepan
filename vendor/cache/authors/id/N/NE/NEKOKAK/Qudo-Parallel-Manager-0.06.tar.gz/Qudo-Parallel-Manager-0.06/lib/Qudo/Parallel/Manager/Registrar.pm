package Qudo::Parallel::Manager::Registrar;
use strict;
use warnings;
1;
