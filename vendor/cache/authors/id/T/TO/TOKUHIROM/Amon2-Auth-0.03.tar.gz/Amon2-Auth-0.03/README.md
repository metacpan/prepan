# NAME

Amon2::Auth - Authentication module for Amon2

# DESCRIPTION

Amon2::Auth is authentication modules for Amon2.

Please read [Amon2::Plugin::Web::Auth](http://search.cpan.org/perldoc?Amon2::Plugin::Web::Auth) for more details.

# AUTHOR

Tokuhiro Matsuno <tokuhirom AAJKLFJEF GMAIL COM>

# SEE ALSO

# LICENSE

Copyright (C) Tokuhiro Matsuno

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
