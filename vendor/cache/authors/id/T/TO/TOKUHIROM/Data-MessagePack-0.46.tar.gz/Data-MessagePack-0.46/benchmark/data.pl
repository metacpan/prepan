+{
    "method" => "handleMessage",
    "params" => [ "user1", "we were just talking", "foo\nbar\nbaz\nqux"  ],
    "id"     => undef,
    "array"  => [ 1, 1024, 70000, -5, 1e5, 1e7, 1, 0, 3.14, sqrt(2), 1 .. 100 ],
};
